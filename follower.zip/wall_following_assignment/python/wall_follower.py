#!/usr/bin/env python
import rospy
import tf
from std_msgs.msg import String, Header
import std_msgs
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from math import sqrt, cos, sin, pi, atan2
import numpy
import sys
import time
from dynamic_reconfigure.server import Server
from wall_following_assignment.cfg import WallfConfig

class PID:
    def __init__(self, Kp, Td, Ti, dt):
        self.Kp = Kp
        self.Td = Td
        self.Ti = Ti
        self.curr_error = 0
        self.prev_error = 0
        self.sum_error = 0
        self.prev_integral = 0
        self.prev_error_deriv = 0
        self.curr_error_deriv = 0
        self.control = 0
        self.dt = dt
        
    def update_control(self, current_error, reset_prev=False):
        
        integral, derivative = 0 , 0
        self.curr_error = current_error

        # Calculating Integral
        integral = self.prev_integral + self.curr_error * self.dt

        # Calculating Derivative
        derivative = (self.curr_error - self.prev_error) / self.dt 

        # Calculating the final output
        self.control = self.Kp * self.curr_error + self.Ti * integral + self.Td * derivative + self.dt

        self.prev_error = self.curr_error
        self.prev_integral = integral
        
    def get_control(self):
        return self.control
        
class WallFollowerHusky:
    def __init__(self):
        rospy.init_node('wall_follower_husky', anonymous=True)

        # self.forward_speed = rospy.get_param("~forward_speed")
        self.forward_speed = rospy.get_param("~forward_speed")
        self.desired_distance_from_wall = rospy.get_param("~desired_distance_from_wall")
        self.hz = 50 
        
        #  Initialising and assigns the returned controller.
        self.pid_controller = self.set_controller(-0.20, -0.6, 0.001, 0.01)

        # command publisher to publish at topic '/husky_1/cmd_vel'
        self.cmd_pub = rospy.Publisher('/husky_1/cmd_vel', Twist, queue_size=10)

        # Creating the laser scan subscriber.
        self.laser_sub = rospy.Subscriber("/husky_1/scan", LaserScan, self.laser_scan_callback)

        # Server call for changing pid values on the fly.
        srv = Server(WallfConfig, self.server_callback)
        
        
    def laser_scan_callback(self, msg):
        distance_from_Wall = 0
        # ranges value range from 0 to 719. So from range 0 - 319 it will be only looking atthe left side of the wall.
        #  range[0] won't give the correct value every time, only during the best case scenerio. 
        distance_from_wall = min(msg.ranges[0:320])
        self.publish_cte(self.desired_distance_from_wall, distance_from_wall)
        self.start_moving()

    # Creates a pid instance and returns it.
    def set_controller(self, kp ,td , ti, dt):
        controller = PID(kp, td, ti, dt)
        return controller

    # Helper method to get the husky moving
    def start_moving(self):
        speed = Twist()
        speed.linear.x = self.forward_speed
        speed.angular.z = self.pid_controller.get_control()
        self.cmd_pub.publish(speed)
    
    # Helper method to Publish the cross track error to topic name /husky_1/cte
    def publish_cte(self, desired_distance , actual_distance):

        cross_track_error = 0
        cross_track_error = desired_distance - actual_distance
        error_pub = rospy.Publisher('/husky_1/cte', std_msgs.msg.Float32 , queue_size=10)
        self.pid_controller.update_control(cross_track_error)
        error_pub.publish(cross_track_error)
    
    # creates a new controller if the values are changed in the reconfigure
    def server_callback(self, config, level):
        self.pid_controller = self.set_controller(config['Kp'], config['Td'], config['Ti'], config['dt'])
        return config

    def run(self):
        rate = rospy.Rate(self.hz)
        while not rospy.is_shutdown():
            rate.sleep()
    
if __name__ == '__main__':
    wfh = WallFollowerHusky()
    wfh.run()
    
    



